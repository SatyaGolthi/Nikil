package com.cg.yamlfileconversion.logger;


import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.Configuration;

import com.cg.yamlfileconversion.exception.YamlException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

@Aspect
@Configuration
public class LoggingAspect {


	private final Logger slf4jLogger = Logger.getLogger(this.getClass());

	private ObjectMapper mapper = new ObjectMapper();

	@Before("execution(* com.cg.yamlfileconversion.service.YamlServiceImpl..*(..))")
	public void controllerLogging(JoinPoint joint) throws YamlException {
		mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
		slf4jLogger.info("Begin of - " + joint.getStaticPart().getSignature().getName() + " method");
		try {
			slf4jLogger.info("Info Input Parameters -:\n "
					+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(joint.getArgs()));
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
	}

	@AfterReturning(pointcut = "execution(* com.cg.yamlfileconversion.service.YamlServiceImpl.*(..))", returning = "result")
	public void serviceSetterMethodLogging(JoinPoint joint, Object result) throws YamlException {
		mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

		try {

			slf4jLogger.info("Info Output Parameters -: \n "
					+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(null != result ? result : ""));
			slf4jLogger.debug("end of  - " + joint.getStaticPart().getSignature().getName() + " method");
		} catch (JsonProcessingException e) {
			throw new YamlException(400, e.getMessage());
		}
	}

}

