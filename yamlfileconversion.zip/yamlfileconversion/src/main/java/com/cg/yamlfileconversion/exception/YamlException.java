package com.cg.yamlfileconversion.exception;

public class YamlException extends Exception { 
	private static final long serialVersionUID = 1L;
	private int code;
	private String status;
	
	
	
	public YamlException() {
		super();
	}
	public YamlException(int code, String status) {
		super();
		this.code = code;
		this.status = status;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "YamlException [code=" + code + ", status=" + status + "]";
	}

}
