package com.cg.yamlfileconversion.utils;

public class YamlUtil {
	
	static final String T = "\t";
	static final String TWO_T = "\t\t";
	static final String THREE_T = "\t\t\t";
	static final String FOUR_T = "\t\t\t\t";
	static final String FIVE_T = "\t\t\t\t\t";
	static final String SIX_T = "\t\t\t\t\t\t";
	static final String SEVEN_T = "\t\t\t\t\t\t\t";


}
