package com.cg.yamlfileconversion.service;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Set;

import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;
import org.springframework.stereotype.Service;

import com.cg.yamlfileconversion.dto.YamlDto;

@Service
public class YamlServiceImpl implements YamlService {

	static final String T = "\t";
	static final String TWO_T = "\t\t";
	static final String THREE_T = "\t\t\t";
	static final String FOUR_T = "\t\t\t\t";
	static final String FIVE_T = "\t\t\t\t\t";
	static final String SIX_T = "\t\t\t\t\t\t";
	static final String SEVEN_T = "\t\t\t\t\t\t\t";

	@Override
	public String getdetails(YamlDto dto) throws IOException {

		FileWriter fileW = new FileWriter("YamlFile.yml");
		
		// Initializing a BufferedWriter
		BufferedWriter buffW = new BufferedWriter(fileW);
		
		buffW.write("swagger: \"2.0\" \n");
		buffW.write("info: \n");
		buffW.write(T + "description: Regarding the pets details \n");
		buffW.write(T + "version: " + dto.getVersion());
		buffW.newLine();
		buffW.write(T + "title: " + dto.getTitle());
		buffW.newLine();
		buffW.write("host: " + dto.getHost());
		buffW.newLine();
		buffW.write("basePath: " + dto.getBasePath());
		buffW.newLine();
		buffW.write("paths: \n");
		
		Set<Class<? extends Object>> allClasses = getclassdetails();
		for (Class<? extends Object> obj : allClasses) {
			if ("ObjectFactory".equals(obj.getSimpleName())) {
				continue;
			}
			buffW.write(T + "/" + obj.getSimpleName().toLowerCase() + "/:");
			buffW.newLine();
			createGet(buffW, obj); // get
			createPost(buffW, obj); // post
			createPut(buffW, obj); // put
			createDelete(buffW, obj);// delete
		}
		buffW.write("definitions: \n");
		createDefinitions(buffW, allClasses);

		buffW.close();
		
		
		return "written successfully";

	}

	private void createDefinitions(BufferedWriter buffW, Set<Class<? extends Object>> allClasses) throws IOException {

		for (Class<? extends Object> obj : allClasses) {
			if ("ObjectFactory".equals(obj.getSimpleName())) {
				continue;
			}
			buffW.write(T + obj.getSimpleName() + ":\n");
			buffW.write(TWO_T + "type: object\n");
			buffW.write(TWO_T + "properties: \n");
			for (Field field : obj.getDeclaredFields()) {
				buffW.write(FOUR_T + field.getName() + ":\n");
				if ("List".equals(field.getType().getSimpleName())) {
					buffW.write(FIVE_T + "type: " + "array\n");
					buffW.write(FIVE_T + "items:\n");
					buffW.write(SEVEN_T + "$ref: " + "\"" + "#/definitions/" + obj.getSimpleName() + "\"");
                    //StringBuilder className = new StringBuilder(field.getName());
					//className.setCharAt(0, (char) (className.charAt(0) - 32));
					//buffW.write(SIX_T + "$ref: " + "\"#/definitions/" + className.toString() + "\"");
				} else if ("XMLGregorianCalendar".equals(field.getType().getSimpleName())) {
					buffW.write(FIVE_T + "type: " + "string\n");
					buffW.write(FIVE_T + "format: " + "date-time\n");
				} else {
					String type = simpleType(field.getType().getSimpleName());
					if ("default".equals(type)) {
						buffW.write(FIVE_T + "$ref: " + "\"#/definitions/" + field.getName() + "\"");
					} else {
						buffW.write(FIVE_T + "type: " + type);
					}
				}
				buffW.newLine();
			}
		}
	}

	String simpleType(String type) {

		switch (type) {

		case "BigInteger":
			return "number";
		case "String":
			return "string";
		case "Double":
			return "number";
		case "Integer":
			return "integer";
		case "Byte":
			return "string";
		case "Boolean":
			return "boolean";
		case "Short":
			return "integer";
		case "BigDecimal":
			return "number";
		case "DateTime"	:
			return "string";
		default:
			return "string";
		}

	}

	private void createDelete(BufferedWriter buffW, Class<? extends Object> obj) throws IOException {
		buffW.write(TWO_T + "delete:");
		buffW.newLine();
		buffW.write(THREE_T + "tags:");
		buffW.newLine();
		buffW.write(FOUR_T + "- " + obj.getSimpleName().toLowerCase());
		buffW.newLine();
		buffW.write(THREE_T + "summary: Delete a  " + obj.getSimpleName() + " with the given entity ");
		buffW.newLine();
		buffW.write(THREE_T + "operationId: delete " + obj.getSimpleName());
		buffW.newLine();
		buffW.write(THREE_T + "produces:");
		buffW.newLine();
		buffW.write(FOUR_T + "- application/xml \n");
		buffW.write(FOUR_T + "- application/json \n");
		createProperties(obj.getDeclaredFields(), buffW, obj.getSimpleName(), "Deleting");
		buffW.write(THREE_T + "responses:");
		buffW.newLine();
		buffW.write(FOUR_T + "200:");
		buffW.newLine();
		buffW.write(FIVE_T + "description: Response is Ok \n");
		buffW.write(FOUR_T + "400: \n");
		buffW.write(FIVE_T + "description: Invalid name supplied \n");
		buffW.write(FOUR_T + "405: \n");
		buffW.write(FIVE_T + "description: Invalid input \n");

	}

	void createPut(BufferedWriter buffW, Class<? extends Object> obj) throws IOException {

		buffW.write(TWO_T + "put:");
		buffW.newLine();
		buffW.write(THREE_T + "tags:");
		buffW.newLine();
		buffW.write(FOUR_T + "- " + obj.getSimpleName().toLowerCase());
		buffW.newLine();
		buffW.write(THREE_T + "summary: Update an Existing " + obj.getSimpleName());
		buffW.newLine();
		buffW.write(THREE_T + "operationId: update " + obj.getSimpleName());
		buffW.newLine();
		buffW.write(THREE_T + "produces:");
		buffW.newLine();
		buffW.write(FOUR_T + "- application/xml \n");
		buffW.write(FOUR_T + "- application/json \n");
		createProperties(obj.getDeclaredFields(), buffW, obj.getSimpleName(), "updating");
		buffW.write(FOUR_T + "- name: body ");
		buffW.newLine();
		buffW.write(FIVE_T + "in: body ");
		buffW.newLine();
		buffW.write(FIVE_T + "schema:");
		buffW.newLine();
		buffW.write(SEVEN_T + "$ref: " + "\"" + "#/definitions/" + obj.getSimpleName() + "\"");
		buffW.newLine();
		buffW.write(THREE_T + "responses:");
		buffW.newLine();
		buffW.write(FOUR_T + "400:");
		buffW.newLine();
		buffW.write(FIVE_T + "description: Invalid input supplied \n");
		buffW.write(FOUR_T + "404: \n");
		buffW.write(FIVE_T + "description: pet not found \n");
		buffW.write(FOUR_T + "405: \n");
		buffW.write(FIVE_T + "description: Validation Exception \n");

		buffW.newLine();
	}

	void createGet(BufferedWriter buffW, Class<? extends Object> obj) throws IOException {
		buffW.write(TWO_T + "get:");
		buffW.newLine();
		buffW.write(THREE_T + "tags:");
		buffW.newLine();
		buffW.write(FOUR_T + "- " + obj.getSimpleName().toLowerCase());
		buffW.newLine();
		buffW.write(THREE_T + "summary: Get " + obj.getSimpleName());
		buffW.newLine();
		buffW.write(THREE_T + "operationId: " + obj.getSimpleName());
		buffW.newLine();
		buffW.write(THREE_T + "produces:");
		buffW.newLine();
		buffW.write(FOUR_T + "- application/xml \n");
		buffW.write(FOUR_T + "- application/json \n");

		createProperties(obj.getDeclaredFields(), buffW, obj.getSimpleName(), "Fetching");
		buffW.write(THREE_T + "responses:");
		buffW.newLine();
		buffW.write(FOUR_T + "200:");
		buffW.newLine();
		buffW.write(FIVE_T + "schema:");
		buffW.newLine();
		buffW.write(SEVEN_T + "$ref: " + "\"" + "#/definitions/" + obj.getSimpleName() + "\"");
		buffW.newLine();
		buffW.write(FIVE_T + "description: Response is Ok \n");
		buffW.write(FOUR_T + "400: \n");
		buffW.write(FIVE_T + "description: Invalid name supplied \n");
		buffW.write(FOUR_T + "404: \n");
		buffW.write(FIVE_T + "description: Cat not found \n");
		buffW.newLine();
	}

	void createPost(BufferedWriter buffW, Class<? extends Object> obj) throws IOException {

		buffW.newLine();
		buffW.write(TWO_T + "post:");
		buffW.newLine();
		buffW.write(THREE_T + "tags:");
		buffW.newLine();
		buffW.write(FOUR_T + "- " + obj.getSimpleName());
		buffW.newLine();
		buffW.write(THREE_T + "summary: Add a " + obj.getSimpleName().toLowerCase() + " to the store");
		buffW.newLine();
		buffW.write(THREE_T + "operationId: addC " + obj.getSimpleName().toLowerCase());
		buffW.newLine();
		buffW.write(THREE_T + "produces:");
		buffW.newLine();
		buffW.write(FOUR_T + "- application/xml \n");
		buffW.write(FOUR_T + "- application/json \n");
		createProperties(obj.getDeclaredFields(), buffW, obj.getSimpleName(), "Creating");

		buffW.write(FOUR_T + "- name: body ");
		buffW.newLine();
		buffW.write(FIVE_T + "in: body ");
		buffW.newLine();
		buffW.write(FIVE_T + "schema:");
		buffW.newLine();
		buffW.write(SEVEN_T + "$ref: " + "\"" + "#/definitions/" + obj.getSimpleName() + "\"");
		buffW.newLine();
		buffW.write(THREE_T + "responses:");
		buffW.newLine();
		buffW.write(FOUR_T + "200:");
		buffW.newLine();
		buffW.write(FIVE_T + "description: Response is Ok \n");
		buffW.write(FOUR_T + "400: \n");
		buffW.write(FIVE_T + "description: Invalid name supplied \n");
		buffW.write(FOUR_T + "405: \n");
		buffW.write(FIVE_T + "description: Invalid input \n");

	}

	public void createProperties(Field[] fields, BufferedWriter buffW, String entityName, String operation)
			throws IOException {

		buffW.write(THREE_T + "parameters: \n");
		for (Field field : fields) {
			//if (field.getName().toLowerCase().contains("id")) {
				if ("Object".equals(field.getType().getSimpleName())) {
					continue;
				}
				if ("List".equals(field.getType().getSimpleName())) {
					continue;
				}
				
				buffW.write("\n" + FOUR_T + "- name: " + field.getName());
				buffW.newLine();
				buffW.write(FIVE_T + "in: query ");
				buffW.newLine();
				if ("XMLGregorianCalendar".equals(simpleType(field.getType().getSimpleName()))) {
					buffW.write(FIVE_T + "type: " + "string\n");
					buffW.write(FIVE_T + "format: " + "date-time\n");
				} else if ("List".equals(simpleType(field.getType().getSimpleName()))) {
					buffW.write(FIVE_T + "type: " + "string");
					buffW.write(FIVE_T + "format: " + "date-time");
				} else
					buffW.write(FIVE_T + "type: " + simpleType(field.getType().getSimpleName()));
				buffW.newLine();
				buffW.write(FIVE_T + "description: " + operation + " the " + entityName);
				buffW.newLine();
				buffW.write(FIVE_T + "required: true");
				buffW.newLine();

			}
		}
	//}

	public Set<Class<? extends Object>> getclassdetails() {
		Reflections reflections = new Reflections("com.cg.yamlfileconversion.model", new SubTypesScanner(false));
		return reflections.getSubTypesOf(Object.class);

	}
}