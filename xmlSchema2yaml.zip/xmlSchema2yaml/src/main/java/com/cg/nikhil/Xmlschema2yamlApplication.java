package com.cg.nikhil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class Xmlschema2yamlApplication {

	public static void main(String[] args) {
		SpringApplication.run(Xmlschema2yamlApplication.class, args);
	}
}
