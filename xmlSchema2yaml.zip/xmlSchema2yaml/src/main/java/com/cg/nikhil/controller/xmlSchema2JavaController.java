package com.cg.nikhil.controller;

import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.nikhil.pojo.Delete;
import com.cg.nikhil.pojo.Get;
import com.cg.nikhil.pojo.Items_;
import com.cg.nikhil.pojo.Parameter;
import com.cg.nikhil.pojo.Post;
import com.cg.nikhil.pojo.Put;
import com.cg.nikhil.pojo.Responses;
import com.cg.nikhil.pojo.Schema;
import com.cg.nikhil.pojo.SwaggerSchema;
import com.cg.nikhil.pojo._200;
import com.cg.nikhil.pojo._400;
import com.cg.nikhil.pojo._404;
import com.cg.nikhil.pojo._405;
import com.cg.nikhil.service.IxmlSchema2yaml;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.dataformat.yaml.YAMLGenerator.Feature;

@RestController
public class xmlSchema2JavaController {

	@Autowired
	IxmlSchema2yaml ixmlSchema2yaml;

	private static final Logger LOGGER = LoggerFactory.getLogger(xmlSchema2JavaController.class);

	private static ObjectMapper mapper = new ObjectMapper(new YAMLFactory().disable(Feature.WRITE_DOC_START_MARKER));

	static final JsonNodeFactory factory = JsonNodeFactory.instance;

	@RequestMapping(value = "/swaggerapi", method = RequestMethod.POST, consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE })
	public SwaggerSchema printYAML(@RequestBody SwaggerSchema obj) throws IOException {

		Set<Class<? extends Object>> entities = getClassDetails();

		ObjectNode paths = factory.objectNode();
		for (Class<? extends Object> entity : entities) {
			if ("ObjectFactory".equals(entity.getSimpleName()))
				continue;

			ObjectNode path = factory.objectNode();

			path.putPOJO("get", createDefaultGet(entity));
			path.putPOJO("post", createDefaultPost(entity));
			path.putPOJO("put", createDefaultPut(entity));
			path.putPOJO("delete", createDefaultDelete(entity));
			paths.set("SLASH" + entity.getSimpleName().toLowerCase(), path);
		}

		obj.setPaths(paths);

		obj.setDefinitions(creteDefinitions());
		mapper.writeValue(System.out, obj);
		mapper.writeValueAsString(obj);
		try {
			FileWriter fw = new FileWriter("C:\\Users\\nsannadi\\testout.txt");
			fw.write(mapper.writeValueAsString(obj).replace("SLASH", "/"));
			fw.close();
		} catch (Exception e) {
			System.out.println(e);

		}
		return obj;

	}

	public static String getYAML(Object obj) throws JsonProcessingException {
		return mapper.writeValueAsString(obj);
	}

	public Post createDefaultPost(Class<? extends Object> entity) throws JsonProcessingException {
		String entityName = entity.getSimpleName();
		Post post = new Post();
		List<String> consumes = new ArrayList<>();
		consumes.add("application/xml");
		consumes.add("application/json");
		List<String> produces = new ArrayList<>();
		produces.add("application/xml");
		produces.add("application/json");
		post.setConsumes(consumes);
		post.setProduces(produces);
		post.setSummary("To Create a new record for the entity: " + entity.getSimpleName());
		post.setDescription(entityName + "to be posted");
		post.setOperationId("postOperation" + entity.getSimpleName());
		Responses responses = new Responses();
		responses.set400(new _400());
		responses.set200(new _200());
		post.setResponses(responses);
		List<Parameter> parameters = new ArrayList<>();
		Parameter parameter = new Parameter();
		parameter.setDescription(entity.getSimpleName() + " Entity to be posted");
		parameter.setIn("body");
		parameter.setName(entity.getSimpleName());
		parameter.setRequired(true);
		Schema schema = new Schema();
		schema.set$ref("#/definitions/" + entity.getSimpleName());
		parameter.setSchema(schema);
		parameters.add(parameter);
		post.setParameters(parameters);
		return post;
	}
//--------------End of post-----------------------	

	/*
	 * @RequestMapping(value = "/getapi", method = RequestMethod.GET, consumes = {
	 * MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE }) public
	 * Get printGet(@RequestBody Get obj) throws JsonGenerationException,
	 * JsonMappingException, IOException { mapper.writeValue(System.out, obj);
	 * 
	 * mapper.writeValueAsString(obj); try { FileWriter fw = new
	 * FileWriter("C:\\Users\\nsannadi\\Post.txt");
	 * fw.write(mapper.writeValueAsString(obj)); fw.close(); } catch (Exception e) {
	 * System.out.println(e); } System.out.println("Success..."); return obj; }
	 * 
	 * public static String getPost(Object obj) throws JsonProcessingException {
	 * return mapper.writeValueAsString(obj); }
	 */

	public Get createDefaultGet(Class<? extends Object> entity) {

		String entityName = entity.getSimpleName();
		Get get = new Get();
		/*
		 * get.getDescription(); get.getOperationId(); get.getParameters();
		 * get.getProduces(); get.getResponses(); get.getSummary(); get.getSecurity();
		 */
		get.setSummary("Entity to be fetched is " + entityName);
		get.setDescription(entityName + " Entity to be fetched");
		get.setOperationId("getOperation" + entityName);
		// If Id of paramter is equal to
		List<Parameter> parameters = new ArrayList<>();
		// List<Parameter> parameters1=new ArrayList<>();

		Parameter limitParam = new Parameter();
		limitParam.setName("limit");
		limitParam.setIn("query");
		limitParam.setDescription("Maximum number of elements per page");
		limitParam.setRequired(true);
		limitParam.setType("integer");
		parameters.add(limitParam);

		Parameter queryParam = new Parameter();
		queryParam.setName("page");
		queryParam.setIn("query");
		queryParam.setDescription("Page number");
		queryParam.setRequired(true);
		queryParam.setType("integer");
		parameters.add(queryParam);
		
		Parameter pagination = new Parameter();
		pagination.setIn("query");
		pagination.setName("offset");
	//	Schema schema = new Schema();
		//schema.setType("integer");
	//	pagination.setSchema(schema);
		
		// ----Based on the id ------
		for (Field field : entity.getDeclaredFields()) {

			if (field.getName().toLowerCase().contains("id")) {
				Parameter parameter = new Parameter();
				parameter.setName(field.getName());
				parameter.setIn("query");
				parameter.setDescription(field.getName() + " Entity to be Fetched");
				parameter.setRequired(true);
				parameter.setType(getType(field.getType().getSimpleName()));
				parameters.add(parameter);
			}

		}
		get.setParameters(parameters);
		List<String> produces = new ArrayList<>();
		produces.add("application/xml");
		produces.add("application/json");
		get.setProduces(produces);
		/*
		 * Responses responses = new Responses(); responses.set400(new _400());
		 * responses.set200(new _200()); get.setResponses(responses);
		 */

		Responses responses = new Responses();
		_200 _200 = new _200();
		_200.setDescription("Successful Response");
		Schema schema = new Schema();
		schema.setType("array");
		Items_ items = new Items_();
		items.set$ref("#/definitions/" + entity.getSimpleName());
		schema.setItems(items);
		_200.setSchema(schema);

		responses.set_200(_200);
		get.setResponses(responses);

		com.cg.nikhil.pojo.Security security = new com.cg.nikhil.pojo.Security();
		List<String> petstoreAuth = new ArrayList<>();

		security.setPetstoreAuth(petstoreAuth);

		return get;
	}
	// --------------------End of Get------------------

	// ---------------------Start of Put----------------
	public Put createDefaultPut(Class<? extends Object> entity) throws JsonProcessingException {
		String entityName = entity.getSimpleName();

		Put put = new Put();

		put.setSummary("Update an existing " + entity.getSimpleName());
		put.setDescription(entityName + "to be Updated");

		put.setOperationId("update" + entity.getSimpleName());
		List<String> consumes = new ArrayList<>();
		consumes.add("application/json");
		consumes.add("application/xml");
		List<String> produces = new ArrayList<>();
		produces.add("application/json");
		produces.add("application/xml");
		put.setConsumes(consumes);
		put.setProduces(produces);
		List<Parameter> parameters = new ArrayList<>();
		Parameter parameter = new Parameter();
		parameter.setIn("body");
		parameter.setName("body");
		parameter.setDescription(entity.getSimpleName() + "object that needs to be added to the store");
		parameter.setRequired(true);
		Schema schema = new Schema();
		schema.set$ref("#/definitions/" + entity.getSimpleName());
		parameter.setSchema(schema);
		parameters.add(parameter);
		put.setParameters(parameters);
		Responses responses = new Responses();
		responses.set400(new _400());
		responses.set_404(new _404());
		responses.set_405(new _405());
		put.setResponses(responses);

		return put;

	}
	// ----------End of Put-------------

	public Delete createDefaultDelete(Class<? extends Object> entity) throws JsonProcessingException {
		String entityName = entity.getSimpleName();

		Delete delete = new Delete();
		delete.setSummary("Deletes a " + entity.getSimpleName());
		delete.setDescription(entityName + "to be Deleted");

		delete.setOperationId("delete" + entity.getSimpleName());
		List<String> produces = new ArrayList<>();
		produces.add("application/json");
		produces.add("application/xml");
		delete.setProduces(produces);
		List<Parameter> parameters = new ArrayList<Parameter>();

		Parameter limitParam = new Parameter();
		limitParam.setName("api_key");
		limitParam.setIn("header");
		limitParam.setRequired(false);
		limitParam.setType("string");
		parameters.add(limitParam);

		for (Field field : entity.getDeclaredFields()) {

			if (field.getName().toLowerCase().contains("id")) {
				Parameter parameter = new Parameter();
				parameter.setName(field.getName());
				parameter.setIn("query");
				parameter.setDescription(field.getName() + " to be delete");
				parameter.setRequired(true);
				parameter.setType(getType(field.getType().getSimpleName()));
				// parameter.setFormat((field.getType().getSimpleName()));
				parameters.add(parameter);
			}
		}
		delete.setParameters(parameters);
		Responses responses = new Responses();
		responses.set400(new _400());
		responses.set_404(new _404());
		delete.setResponses(responses);

		return delete;

	}

	// --------Pet Definition--------------
	/*
	 * @RequestMapping(value = "/petdefprint") public Pet printPetDefinition()
	 * throws JsonGenerationException, JsonMappingException, IOException {
	 * 
	 * Pet pet = createDefaultPetDefinition("Requisitiuon"); try { FileWriter fw =
	 * new FileWriter("C:\\Users\\nsannadi\\Post1.txt");
	 * fw.write(mapper.writeValueAsString(pet)); fw.close(); } catch (Exception e) {
	 * System.out.println(e); } System.out.println("Success..."); return pet; }
	 * 
	 * public Pet createDefaultPetDefinition(String entityName) { Pet pet = new
	 * Pet();
	 * 
	 * com.cg.nikhil.pojo.Tags tags = new com.cg.nikhil.pojo.Tags();
	 * tags.setType(""); pet.setType("object"); return pet;
	 * 
	 * }
	 */
	@SuppressWarnings("deprecation")
	public ObjectNode creteDefinitions() {

		Set<Class<? extends Object>> allClasses = getClassDetails();

		Set<Class<? extends Enum>> allEnums = getEnumDetails();

		ObjectNode schema = factory.objectNode();

		for (Class<? extends Object> obj : allClasses) {
			if ("ObjectFactory".equals(obj.getSimpleName()))
				continue;
			ObjectNode entity = factory.objectNode();
			entity.put("type", "object");
			// entity.p
			ObjectNode properties = factory.objectNode();
			for (Field field : obj.getDeclaredFields()) {
				// setProperty based on fieldType

				properties.set(field.getName(), setProperty(field));
			}
			entity.set("properties", properties);
			schema.set(obj.getSimpleName(), entity);

		}
		for (Class<? extends Enum> enumEntity : allEnums) {
			ObjectNode entity = factory.objectNode();
			entity.put("type", "string");
			ArrayNode arrayNode = factory.arrayNode();
			for (Field field : enumEntity.getDeclaredFields()) {
				// setProperty based on fieldType
				arrayNode.add(field.getName());
			}
			entity.put("enum", arrayNode);
			schema.set(enumEntity.getSimpleName(), entity);

		}
		return schema;
	}

	private ObjectNode setProperty(Field field) {
		ObjectNode property = factory.objectNode();
		String type = field.getType().getSimpleName();

		switch (type) {

		case "String":
			property.put("type", "string");
			property.put("example", "helloworld");
			break;
		case "BigInteger":
			property.put("type", "integer");
			property.put("format", "int64");
			property.put("example", 6598741);
			break;
		case "Integer":
			property.put("type", "integer");
			property.put("format", "int32");
			property.put("example", 6598);
			break;
		case "int":
			property.put("type", "integer");
			property.put("format", "int32");
			property.put("example", 6985);
			break;
		case "List":
			ObjectNode items = factory.objectNode();
			property.put("type", "array");
			StringBuilder fieldName = new StringBuilder(field.getName());
			fieldName.setCharAt(0, (char) (fieldName.charAt(0) - 32));
			items.put("$ref", "#/definitions/" + fieldName.toString());
			property.putPOJO("items", items);
			break;
		case "Boolean":
			property.put("type", "boolean");
			property.put("example", "true");
			break;
		case "BigDecimal":
			property.put("type", "number");
			property.put("example", 655498.5456);
			break;
		case "XMLGregorianCalendar":
			property.put("type", "string");
			property.put("format", "date");
			property.put("example", 12252019);
			break;
		// YEt to work
		default:
			property.put("$ref", "#/definitions/" + field.getType().getSimpleName());
			break;

		}
		/*
		 * if ("object".equals(type)) { property.put("$ref", "#/definitions/" +
		 * field.getType().getSimpleName()); } else { if (type != null) {
		 * property.put("type", type); } }
		 */
		return property;
	}

	String getType(String fieldType) {

		LOGGER.info("Field Type  " + fieldType.toLowerCase().toString());

		switch (fieldType.toLowerCase()) {

		case "string":
			return "string";
		case "biginteger":
			return "integer";
		case "integer":
			return "integer";
		case "int":
			return "integer"; // Yet to Work
		case "list":
			return "string";
		case "boolean":
			return "boolean";
		case "bigdecimal":
			return "integer";
		case "XMLGregorianCalendar":
			return "string";
		case "qname":
			return "string";
		case "role":
			return "integer";
		case "xmlgregoriancalendar":
			return "string"; // YEt to work
		default:
			return "string";

		}

	}

	public Set<Class<? extends Object>> getClassDetails() {
		Reflections reflections = new Reflections("com.cg.nikhil.entity", new SubTypesScanner(false));
		return reflections.getSubTypesOf(Object.class);

	}

	public Set<Class<? extends Enum>> getEnumDetails() {
		Reflections reflections = new Reflections("com.cg.nikhil.entity", new SubTypesScanner(false));
		return reflections.getSubTypesOf(Enum.class);

	}

}
